---
title: "new JSZip() or JSZip()"
layout: default
section: api
---

Create a new JSZip instance.

__Returns__ : A new JSZip.

__Since__: v1.0.0

## Example

```js
var zip = new JSZip();
// same as
var zip = JSZip();
```
